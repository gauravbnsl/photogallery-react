import React from 'react'; 

const Title = () => {
    return (
        <div>snapgram</div>
    )
}

export default Title;